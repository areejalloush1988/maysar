"use strict";
(() => {
  const KEY='maysar-brokerage-v2',SESSION='maysar-auth-v2';
  const empty=()=>({version:2,user:null,company:{},assessment:{country:'ae',product:'working',sector:'',months:'',revenue:'',obligations:'',amount:'',purpose:'',urgency:'month'},documents:[],applications:[],events:[],messages:[],offers:[],reports:[],consents:[],acceptances:[],language:'ar',demo:false,step:0});
  let state;
  try{state=JSON.parse(localStorage.getItem(KEY));if(state?.version!==2)state=empty();}catch{state=empty();}
  let persistent=true;
  function save(){try{const local=configured&&!state.demo&&state.user?{...empty(),language:state.language}:state;localStorage.setItem(KEY,JSON.stringify(local));}catch{persistent=false;throw new Error('storage_full');}}
  const config=window.MAYSAR_CONFIG||{};
  const configured=Boolean(config.supabaseUrl&&config.supabasePublishableKey);
  let auth;
  try{auth=JSON.parse(sessionStorage.getItem(SESSION)||'null');}catch{auth=null;}
  function keepAuth(value){auth=value;try{if(value)sessionStorage.setItem(SESSION,JSON.stringify(value));else sessionStorage.removeItem(SESSION);}catch{}}
  async function api(path,{method='GET',body,headers={},binary=false,retried=false}={}){
    const requestHeaders={apikey:config.supabasePublishableKey,...(auth?.access_token?{Authorization:'Bearer '+auth.access_token}:{}),...headers};
    if(body!==undefined&&!binary)requestHeaders['Content-Type']='application/json';
    let response;
    try{response=await fetch(config.supabaseUrl.replace(/\/$/,'')+path,{method,headers:requestHeaders,body:body===undefined?undefined:binary?body:JSON.stringify(body)});}catch{throw new Error('network');}
    if(response.status===401&&auth?.refresh_token&&!path.startsWith('/auth/')&&!retried){
      const refreshed=await fetch(config.supabaseUrl+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{apikey:config.supabasePublishableKey,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:auth.refresh_token})});
      if(!refreshed.ok){keepAuth(null);throw new Error('session_expired');}
      keepAuth(await refreshed.json());
      return api(path,{method,body,headers,binary,retried:true});
    }
    if(!response.ok){let error;try{error=await response.json();}catch{}throw new Error(error?.msg||error?.message||error?.error_description||'request_failed');}
    if(response.status===204||response.headers.get('content-length')==='0')return null;
    if(binary)return response.blob();
    const text=await response.text();return text?JSON.parse(text):null;
  }
  async function database(){return new Promise((resolve,reject)=>{if(!window.indexedDB)return reject(new Error('storage_unavailable'));const r=indexedDB.open('maysar-documents-v2',1);r.onupgradeneeded=()=>r.result.createObjectStore('files');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(new Error('storage_unavailable'));});}
  async function blobOperation(kind,key,value){const db=await database();try{return await new Promise((resolve,reject)=>{const tx=db.transaction('files',kind==='get'?'readonly':'readwrite');const os=tx.objectStore('files');const req=kind==='put'?os.put(value,key):kind==='delete'?os.delete(key):os.get(key);let result;req.onsuccess=()=>{result=req.result;};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(new Error('storage_full'));tx.onabort=()=>reject(new Error('storage_full'));});}finally{db.close();}}
  async function loadRemote(){
    const user=await api('/auth/v1/user');
    const [profiles,companies,applications,documents,messages,offers,events,reports,consents,acceptances,overrides]=await Promise.all([
      api('/rest/v1/profiles?select=*'),api('/rest/v1/companies?select=*'),api('/rest/v1/applications?select=*&order=created_at.desc'),api('/rest/v1/documents?select=*'),api('/rest/v1/messages?select=*&order=created_at.asc'),api('/rest/v1/offers?select=*'),api('/rest/v1/application_events?select=*&order=created_at.asc'),api('/rest/v1/reports?select=*'),api('/rest/v1/consents?select=*'),api('/rest/v1/offer_acceptances?select=*'),api('/rest/v1/directory_overrides?select=*')
    ]);
    const profile=profiles?.find(p=>p.id===user.id);
    state={...empty(),language:state.language,demo:false,user:{id:user.id,email:user.email,name:profile?.display_name||user.email,role:profile?.role||'client'},company:companies?.find(c=>c.user_id===user.id)?.data||{},applications:applications||[],documents:documents||[],messages:messages||[],offers:offers||[],events:events||[],reports:reports||[],consents:consents||[],acceptances:acceptances||[],companies:companies||[]};
    state.provider_overrides=(overrides||[]).map(x=>({id:x.id,...x.criteria}));
    const own=companies?.find(c=>c.user_id===user.id);if(own){state.company.id=own.id;state.assessment=own.assessment||empty().assessment;}
    return state;
  }
  async function init(){if(configured&&auth){try{return await loadRemote();}catch(e){if(e.message==='session_expired')state.user=null;throw e;}}return state;}
  function demo(){
    if(!state.demo){const {language,assessment,step}=state;state=empty();state.language=language;state.assessment=assessment;state.step=step;state.demo=true;}
    state.user={id:'demo-client',name:state.language==='ar'?'مساحة العميل التجريبية':'Demo client workspace',email:'demo@example.com',role:'client'};save();
    return state;
  }
  async function signUp(email,password,name){if(!configured)throw new Error('not_configured');const response=await api('/auth/v1/signup',{method:'POST',body:{email,password,data:{display_name:name}}});if(response.access_token){keepAuth(response);await loadRemote();}return response;}
  async function signIn(email,password){if(!configured)throw new Error('not_configured');keepAuth(await api('/auth/v1/token?grant_type=password',{method:'POST',body:{email,password}}));return loadRemote();}
  async function signOut(){if(configured&&auth){try{await api('/auth/v1/logout',{method:'POST'});}catch{}}keepAuth(null);if(state.demo){state.user=null;save();}else{const language=state.language;state=empty();state.language=language;save();}return state;}
  async function recover(email){if(!configured)throw new Error('not_configured');return api('/auth/v1/recover',{method:'POST',body:{email}});}
  async function updateCompany(data){
    if(state.demo){state.company={...state.company,...data};save();return;}
    const rows=await api('/rest/v1/companies?on_conflict=user_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=representation'},body:{user_id:state.user.id,data,assessment:state.assessment}});
    state.company={...data,id:rows[0].id};
  }
  async function saveAssessment(){if(state.demo||!state.user){save();return;}await updateCompany(state.company);}
  async function addDocument(file,type){
    const id=crypto.randomUUID();
    const doc={id,user_id:state.user.id,type,name:file.name,mime:file.type,size:file.size,status:'uploaded',created_at:new Date().toISOString()};
    if(state.demo){await blobOperation('put',id,file);state.documents.push(doc);try{save();}catch(e){state.documents.pop();await blobOperation('delete',id);throw e;}}
    else{
      const ext={ 'application/pdf':'pdf','image/jpeg':'jpg','image/png':'png' }[file.type];doc.object_path=state.user.id+'/'+id+'.'+ext;
      await api('/storage/v1/object/maysar-documents/'+doc.object_path,{method:'POST',binary:true,headers:{'Content-Type':file.type},body:file});
      try{const result=await api('/rest/v1/documents',{method:'POST',headers:{Prefer:'return=representation'},body:doc});state.documents.push(result[0]);}catch(e){try{await api('/storage/v1/object/maysar-documents',{method:'DELETE',body:{prefixes:[doc.object_path]}});}catch{}throw e;}
    }
    return doc;
  }
  async function getDocument(doc){if(state.demo)return blobOperation('get',doc.id);return api('/storage/v1/object/authenticated/maysar-documents/'+doc.object_path,{binary:true});}
  async function deleteDocument(id){const doc=state.documents.find(d=>d.id===id);if(!doc)return;if(state.demo){await blobOperation('delete',id);state.documents=state.documents.filter(d=>d.id!==id);save();}else{await api('/storage/v1/object/maysar-documents',{method:'DELETE',body:{prefixes:[doc.object_path]}});await api('/rest/v1/documents?id=eq.'+encodeURIComponent(id),{method:'DELETE'});state.documents=state.documents.filter(d=>d.id!==id);}}
  async function submit(lenderIds,consent){
    if(!consent)throw new Error('consent_required');
    if(MaysarDomain.validateAssessment(state.assessment).length)throw new Error('invalid_assessment');
    if(state.demo){
      const id=crypto.randomUUID(),now=new Date().toISOString();const application={id,user_id:state.user.id,product:state.assessment.product,amount:Number(state.assessment.amount),country:state.assessment.country,currency:MaysarDomain.currency(state.assessment.country),answers:{...state.assessment},company_snapshot:{...state.company},lender_ids:[...lenderIds],status:'review',created_at:now,updated_at:now};
      state.applications.unshift(application);state.events.push({id:crypto.randomUUID(),application_id:id,status:'review',note:state.language==='ar'?'تم إنشاء طلب مراجعة داخلية. لم يُرسل إلى جهة تمويل.':'Internal review created. Not sent to a finance provider.',created_at:now});state.consents.push({id:crypto.randomUUID(),application_id:id,lender_ids:[...lenderIds],purpose:'application_review_and_selected_provider_sharing',created_at:now});save();return application;
    }
    const result=await api('/rest/v1/rpc/submit_application',{method:'POST',body:{p_answers:state.assessment,p_company_id:state.company.id,p_lender_ids:lenderIds,p_consent:consent}});await loadRemote();return state.applications.find(a=>a.id===(typeof result==='string'?result:result.id));
  }
  async function addMessage(applicationId,body,role='client'){
    const m={id:crypto.randomUUID(),application_id:applicationId,user_id:state.user.id,body,sender_role:state.demo?role:state.user.role,created_at:new Date().toISOString()};
    if(state.demo){state.messages.push(m);save();return m;}
    const result=await api('/rest/v1/messages',{method:'POST',headers:{Prefer:'return=representation'},body:{application_id:applicationId,user_id:state.user.id,body}});state.messages.push(result[0]);return result[0];
  }
  async function updateStatus(id,status,note,reference){
    const app=state.applications.find(a=>a.id===id);MaysarDomain.nextStatus(app.status,status,note,reference);
    if(status==='submitted'&&!app.lender_ids.length)throw new Error('selected_provider_consent_required');
    if(status==='offer'&&!state.offers.some(o=>o.application_id===id))throw new Error('offer_required');
    if(status==='contract'&&!state.acceptances.some(o=>o.application_id===id))throw new Error('offer_selection_required');
    if(state.demo){app.status=status;app.updated_at=new Date().toISOString();app.reference=reference;state.events.push({id:crypto.randomUUID(),application_id:id,status,note,reference,created_at:app.updated_at});save();}
    else{await api('/rest/v1/rpc/change_application_status',{method:'POST',body:{p_id:id,p_status:status,p_note:note,p_reference:reference}});await loadRemote();}
  }
  async function addOffer(data){
    MaysarDomain.compareOffers([data]);
    if(!state.applications.some(a=>a.id===data.application_id&&['submitted','offer'].includes(a.status)))throw new Error('offer_stage_required');
    const o={...data,id:crypto.randomUUID(),created_at:new Date().toISOString(),demo:state.demo};
    if(state.demo){state.offers.push(o);save();return o;}
    const rows=await api('/rest/v1/offers',{method:'POST',headers:{Prefer:'return=representation'},body:o});state.offers.push(rows[0]);return rows[0];
  }
  async function acceptOffer(offer){
    if(state.acceptances.some(x=>x.application_id===offer.application_id))throw new Error('already_accepted');
    if(!state.applications.some(a=>a.id===offer.application_id&&['offer','contract'].includes(a.status))||offer.valid_until&&new Date(offer.valid_until+'T23:59:59+04:00')<new Date())throw new Error('invalid_offer_selection');
    const acceptance={id:crypto.randomUUID(),application_id:offer.application_id,offer_id:offer.id,user_id:state.user.id,created_at:new Date().toISOString()};
    if(state.demo){state.acceptances.push(acceptance);save();}else{await api('/rest/v1/offer_acceptances',{method:'POST',body:acceptance});state.acceptances.push(acceptance);}
  }
  async function createReport(providerList=MaysarDomain.lenders){
    const report={id:crypto.randomUUID(),user_id:state.user.id,created_at:new Date().toISOString(),data:{company:{...state.company},answers:{...state.assessment},documents:state.documents.map(({type,status})=>({type,status})),lender_ids:MaysarDomain.matches(state.assessment,providerList).map(m=>m.lender.id),providers_snapshot:JSON.parse(JSON.stringify(providerList)),kind:'preliminary',payment_status:'not_charged'}};
    if(state.demo){state.reports.unshift(report);save();}else{await api('/rest/v1/reports',{method:'POST',body:report});state.reports.unshift(report);}return report;
  }
  async function reset(){for(const d of state.documents)if(state.demo){try{await blobOperation('delete',d.id);}catch{}}const language=state.language;state=empty();state.language=language;save();keepAuth(null);return state;}
  async function saveProvider(override){if(state.demo){state.provider_overrides=[...(state.provider_overrides||[]).filter(o=>o.id!==override.id),override];save();}else{const {id,...criteria}=override;await api('/rest/v1/directory_overrides?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates'},body:{id,criteria,updated_by:state.user.id}});state.provider_overrides=[...(state.provider_overrides||[]).filter(o=>o.id!==id),override];}}
  window.MaysarStore={get state(){return state;},get persistent(){return persistent;},configured,save,init,demo,signUp,signIn,signOut,recover,updateCompany,saveAssessment,addDocument,getDocument,deleteDocument,submit,addMessage,updateStatus,addOffer,acceptOffer,createReport,saveProvider,reset,refresh:loadRemote};
})();
