"use strict";
(() => {
  async function download(report,{language='ar',providers=[]}={}){
    await Promise.all([document.fonts.load('400 14px Maysar'),document.fonts.load('700 14px Maysar')]);
    const rtl=language==='ar',t=(ar,en)=>rtl?ar:en,D=window.MaysarDomain;
    const a=report.data.answers,c=report.data.company,sourceProviders=report.data.providers_snapshot||providers;
    const ms=D.matches(a,sourceProviders).filter(m=>report.data.lender_ids.includes(m.lender.id));
    const currency={ae:'AED',sa:'SAR',kw:'KWD',qa:'QAR',bh:'BHD',om:'OMR'}[a.country]||'AED';
    const n=value=>new Intl.NumberFormat(rtl?'ar-AE':'en-AE',{maximumFractionDigits:['KWD','BHD','OMR'].includes(currency)?3:2}).format(Number(value)||0);
    const date=new Intl.DateTimeFormat(rtl?'ar-AE':'en-AE',{day:'numeric',month:'long',year:'numeric',timeZone:'Asia/Dubai'}).format(new Date(report.created_at));
    const pageWidth=595,pageHeight=842,pages=[];let canvas,pen,links,y,pageNo=0;
    const margin=38,inner=pageWidth-margin*2;
    function font(size=11,bold=false){pen.font=`${bold?700:400} ${size}px Maysar, Arial, sans-serif`;}
    function write(value,x,baseline,size=11,bold=false,color='#40205f',direction=rtl){font(size,bold);pen.fillStyle=color;pen.direction=direction?'rtl':'ltr';pen.textAlign=direction?'right':'left';pen.fillText(String(value),x,baseline);}
    function box(x,top,width,height,color,radius=7){pen.fillStyle=color;pen.beginPath();pen.roundRect(x,top,width,height,radius);pen.fill();}
    function finish(){write(t('تقرير أولي مبني على بيانات غير مدققة. القرار لدى الجهة الممولة.','Preliminary report using unverified input. Provider assessment applies.'),rtl?pageWidth-margin:margin,pageHeight-30,8,false,'#786b87');write(String(pageNo),rtl?margin:pageWidth-margin,pageHeight-30,8,false,'#786b87',!rtl);const data=atob(canvas.toDataURL('image/jpeg',.94).split(',')[1]);pages.push({image:Uint8Array.from(data,c=>c.charCodeAt(0)),width:canvas.width,height:canvas.height,links});}
    function start(){if(canvas)finish();pageNo++;canvas=document.createElement('canvas');canvas.width=pageWidth*2;canvas.height=pageHeight*2;pen=canvas.getContext('2d');pen.scale(2,2);links=[];box(0,0,pageWidth,pageHeight,'#fff',0);box(0,0,pageWidth,94,'#40205f',0);write(t('مُيَسَّر','MAYSAR'),rtl?pageWidth-margin:margin,33,20,true,'#e4cff5');write(t('تقرير مطابقة أولي','Preliminary financing report'),rtl?pageWidth-margin:margin,69,19,true,'#fff');write(D.reference(report.id),rtl?margin:pageWidth-margin,36,9,false,'#dbc4ec',!rtl);y=118;}
    function space(height){if(y+height>pageHeight-62)start();}
    function lines(value,maxWidth,size=11){font(size);const words=String(value).split(/\s+/),result=[];let line='';for(const word of words){const test=line?line+' '+word:word;if(line&&pen.measureText(test).width>maxWidth){result.push(line);line=word;}else line=test;}if(line)result.push(line);return result;}
    function paragraph(value,{size=11,bold=false,color='#786b87',gap=7,indent=0}={}){for(const line of lines(value,inner-indent,size)){space(size*1.8);write(line,rtl?pageWidth-margin-indent:margin+indent,y,size,bold,color);y+=size*1.8;}y+=gap;}
    function heading(value){space(45);y+=8;paragraph(value,{size:14,bold:true,color:'#40205f',gap:7});}
    function pair(label,value){space(45);box(margin,y-13,inner,31,'#f6f0fb',4);write(label,rtl?pageWidth-margin-10:margin+10,y+6,10,false,'#786b87');const text=String(value);const valueLines=lines(text,inner*.59,10);if(valueLines.length===1)write(text,rtl?margin+10:pageWidth-margin-10,y+6,10,true,'#40205f',!rtl);else{y+=33;paragraph(text,{size:10,bold:true});return;}y+=39;}
    start();
    paragraph(c.name||t('ملف الشركة','Company profile'),{size:19,bold:true,color:'#40205f'});
    paragraph(date+' · '+currency,{size:10,color:'#786b87',gap:16});
    paragraph(t('هذا التقرير لا يمثل موافقة على التمويل أو عرضًا من أي جهة، ولا يعرض نسبة قبول متوقعة.','This report is not a credit approval or a provider offer and does not state an approval probability.'),{size:10,color:'#7650a5',gap:14});
    heading(t('١. ملخص طلب التمويل','1. Funding request summary'));
    const product=D.products.find(p=>p.id===a.product);
    pair(t('الغرض التمويلي','Financing purpose'),product?.[rtl?'ar':'en']||a.product);
    pair(t('المبلغ المطلوب','Requested amount'),n(a.amount)+' '+currency);
    pair(t('الإيراد السنوي المصرّح','Declared annual revenue'),n(a.revenue)+' '+currency);
    pair(t('التزامات التمويل الشهرية','Monthly financing obligations'),n(a.obligations)+' '+currency);
    pair(t('مدة النشاط','Months in business'),n(a.months)+' '+t('شهرًا','months'));
    paragraph(t('استخدام التمويل: ','Use of funds: ')+a.purpose,{size:11});
    heading(t('٢. تجهيز الملف والمستندات','2. Profile and documents'));
    const completeness=D.completeness(c,report.data.documents,a.product);
    paragraph(t('اكتمال البيانات والمستندات: ','Information and document completeness: ')+completeness.percent+'%. '+t('هذه نسبة اكتمال وليست نسبة قبول.','This is completeness, not approval probability.'),{size:11});
    const docNames={license:['الرخصة التجارية','Trade licence'],bank:['كشف حساب بنكي','Bank statement'],invoice:['الفاتورة المستحقة','Outstanding invoice'],contract:['العقد أو أمر الشراء','Contract / purchase order'],quotation:['عرض سعر المعدات','Equipment quotation'],payroll:['كشف الرواتب','Payroll schedule'],project:['مستندات المشروع','Project documents']};
    for(const type of completeness.requirements){const present=report.data.documents.some(d=>d.type===type&&d.status!=='rejected');paragraph((docNames[type]?.[rtl?0:1]||type)+' — '+(present?t('مرفوع، ومراجعة المحتوى مطلوبة.','Uploaded; content review is still needed.'):t('مطلوب استكماله.','Still needed.')),{size:10});}
    space(ms.length?205:80);heading(t('٣. جهات وقنوات للاستكشاف','3. Providers and routes to explore'));
    if(!ms.length)paragraph(t('لم تظهر مطابقة في الدليل الحالي. يمكن طلب مراجعة عامة أو استكشاف خيارات خارج نطاق الدليل.','No match was found in this directory. Request a general review or explore routes outside its coverage.'));
    for(const match of ms){const l=match.lender;space(155);paragraph(l.name[rtl?'ar':'en'],{size:13,bold:true,color:'#40205f'});paragraph(l.description[rtl?'ar':'en'],{size:10});paragraph(match.status==='potential'?t('توافق أولي مع الشروط المنشورة التي فُحصت. تبقى الدراسة الائتمانية والمستندات لدى الممول.','Initial fit with the checked published criteria. Credit and document review remain with the provider.'):t('توجد معلومات غير مؤكدة عن الشروط. يجب مراجعتها مباشرة مع الجهة.','Some detailed criteria are unconfirmed. Check them directly with the provider.'),{size:10,color:'#7650a5'});paragraph(t('تاريخ مراجعة المصدر: ','Source reviewed: ')+l.reviewed,{size:9});space(25);const baseline=y;paragraph(l.url,{size:9,color:'#7650a5'});links.push({url:l.url,x:margin,y:baseline-11,w:inner,h:Math.max(18,y-baseline)});y+=10;}
    heading(t('٤. الخطوة التالية','4. Next step'));
    paragraph(t('استكمل النواقص، وراجع صحة المعلومات والشروط الحالية مع فريق الوساطة والجهة المناسبة. أي إرسال خارجي يحتاج موافقة محددة، وأي عرض يجب مراجعته قبل التعاقد.','Complete missing information and confirm your details and current criteria with the broker and relevant provider. External sharing requires specific consent, and any offer should be reviewed before contracting.'));
    finish();
    const pdf=encodeReportPdf(pages,pageWidth,pageHeight,language);
    const url=URL.createObjectURL(pdf),link=document.createElement('a');link.href=url;link.download='Maysar-'+D.reference(report.id)+'.pdf';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  }
  window.MaysarPDF={download};
})();

function encodeReportPdf(pages, width, height, language = "ar") {
  const encoder = new TextEncoder();
  const chunks = [];
  const offsets = [0];
  let position = 0;
  const text = (value) => bytes(encoder.encode(value));

  function bytes(value) {
    chunks.push(value);
    position += value.length;
  }

  function start(id) {
    offsets[id] = position;
    text(id + " 0 obj\n");
  }

  function object(id, body) {
    start(id);
    text(body + "\nendobj\n");
  }

  function stream(id, dictionary, value) {
    start(id);
    text("<< " + dictionary + " /Length " + value.length + " >>\nstream\n");
    bytes(value);
    text("\nendstream\nendobj\n");
  }

  const pageIds = [];
  const catalog = 1;
  const root = 2;
  let next = 3;
  text("%PDF-1.4\n");
  bytes(Uint8Array.from([37, 226, 227, 207, 211, 10]));
  object(catalog, "<< /Type /Catalog /Pages 2 0 R /Lang (" + (language === "en" ? "en-AE" : "ar-AE") + ") >>");
  for (const page of pages) {
    const id = next++;
    const imageId = next++;
    const contentsId = next++;
    const annots = page.links.map(() => next++);
    const annotationList = annots.map((annotation) => annotation + " 0 R").join(" ");
    pageIds.push(id + " 0 R");
    object(id, "<< /Type /Page /Parent " + root + " 0 R /MediaBox [0 0 " + width + " " + height +
      "] /Resources << /XObject << /Im0 " + imageId + " 0 R >> >> /Contents " + contentsId +
      " 0 R /Annots [" + annotationList + "] >>");
    stream(imageId, "/Type /XObject /Subtype /Image /Width " + page.width + " /Height " + page.height +
      " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode", page.image);
    stream(contentsId, "", encoder.encode("q\n" + width + " 0 0 " + height + " 0 0 cm\n/Im0 Do\nQ\n"));
    for (const [index, link] of page.links.entries()) {
      const uri = link.url.replace(/[()\\]/g, "\\$&");
      const rect = [link.x, height - link.y - link.h, link.x + link.w, height - link.y].join(" ");
      object(annots[index], "<< /Type /Annot /Subtype /Link /Border [0 0 0] /Rect [" + rect +
        "] /A << /S /URI /URI (" + uri + ") >> >>");
    }
  }
  object(root, "<< /Type /Pages /Count " + pages.length + " /Kids [" + pageIds.join(" ") + "] >>");
  const xref = position;
  text("xref\n0 " + next + "\n0000000000 65535 f \n");
  for (let index = 1; index < next; index++) text(String(offsets[index]).padStart(10, "0") + " 00000 n \n");
  text("trailer\n<< /Size " + next + " /Root " + catalog + " 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
  return new Blob(chunks, { type: "application/pdf" });
}
