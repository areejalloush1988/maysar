import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
test('standalone preserves executable scripts and embeds assets without replacement-string corruption',async()=>{
  const root=path.resolve(import.meta.dirname,'..'),out=await fs.mkdtemp(path.join(os.tmpdir(),'maysar-build-'));
  try{
    await promisify(execFile)(process.execPath,['scripts/build.mjs'],{cwd:root,env:{...process.env,MAYSAR_OUTPUT_DIR:out}});
    const html=await fs.readFile(path.join(out,'Maysar-App.html'),'utf8');
    const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
    assert.equal(scripts.length,6);assert.equal(html.split('</body>').length,2);
    assert.ok(html.indexOf('<div id="app">')<html.indexOf('<script>'));
    const logo='data:image/png;base64,'+(await fs.readFile(path.join(root,'assets/moyassar-mark.png'))).toString('base64');
    for(const [i,file] of ['config.js','core.js','storage.js','pdf-v2.js','views.js','ui.js'].entries()){
      const expected=(await fs.readFile(path.join(root,file),'utf8')).replace(/<\/script/gi,'<\\/script').split('assets/moyassar-mark.png').join(logo);
      assert.ok(scripts[i]===expected,'Embedded script differs from '+file);
      new vm.Script(scripts[i],{filename:file});
    }
    assert.equal(/(?:src|href)="assets\//.test(html),false);assert.equal(/url\(['"]?assets\//.test(html),false);
  }finally{await fs.rm(out,{recursive:true,force:true});}
});
