"use strict";
(() => {
  const products = [
    {id:'working',icon:'briefcase',ar:'رأس المال العامل',en:'Working capital',descAr:'سيولة لتشغيل أعمالك وتغطية التزاماتك اليومية.',descEn:'Liquidity for day-to-day business operations.'},
    {id:'invoice',icon:'file',ar:'تمويل الفواتير',en:'Invoice finance',descAr:'استكشف تمويل مستحقاتك قبل موعد تحصيلها.',descEn:'Explore funding against outstanding receivables.'},
    {id:'purchase',icon:'package',ar:'العقود وأوامر الشراء',en:'Contracts & purchase orders',descAr:'تجهيز احتياجات تنفيذ عقودك وطلبات عملائك.',descEn:'Prepare funding for contracts and customer orders.'},
    {id:'equipment',icon:'building',ar:'المعدات والمركبات',en:'Equipment & vehicles',descAr:'حلول للأصول التي تحتاجها شركتك للنمو.',descEn:'Explore funding for business assets and fleets.'},
    {id:'payroll',icon:'user',ar:'تمويل الرواتب',en:'Payroll finance',descAr:'تنظيم احتياج السيولة لمستحقات فريقك.',descEn:'Plan liquidity for your team’s payroll.'},
    {id:'guarantee',icon:'check',ar:'خطابات الضمان',en:'Bank guarantees',descAr:'تجهيز متطلبات الضمانات والعطاءات.',descEn:'Prepare for tender and contractual guarantees.'},
    {id:'property',icon:'home',ar:'تمويل المشاريع العقارية',en:'Property development',descAr:'دراسة احتياج تمويل مشروع تطوير عقاري.',descEn:'Review a property development funding need.'},
    {id:'explore',icon:'sparkle',ar:'ساعدني أختار',en:'Help me choose',descAr:'ابدأ بهدفك، ونرتّب لك مسارات البحث.',descEn:'Start with your goal and explore suitable routes.'}
  ];
  const lenders = [
    {id:'beehive-term',name:{ar:'بيهايف — تمويل لأجل',en:'Beehive — Term finance'},mark:'BH',country:'ae',products:['working','equipment','explore'],minMonths:24,minRevenue:2000000,minAmount:200000,maxAmount:2000000,url:'https://www.beehive.ae/funding-options',reviewed:'2026-11-17',partner:false,kind:'lender',description:{ar:'شروط أولية منشورة للشركات القائمة. تخضع الموافقة للدراسة الائتمانية.',en:'Published initial criteria for established businesses; credit review still applies.'}},
    {id:'beehive-invoice',name:{ar:'بيهايف — تمويل فواتير',en:'Beehive — Invoice finance'},mark:'BH',country:'ae',products:['invoice','explore'],minMonths:24,minRevenue:8000000,minAmount:500000,maxAmount:2500000,url:'https://www.beehive.ae/funding-options',reviewed:'2026-11-17',partner:false,kind:'lender',description:{ar:'تسهيل مقابل فواتير بين الشركات، وفق شروط الفاتورة والمنشأة.',en:'A facility against B2B invoices, subject to business and invoice review.'}},
    {id:'crediblex',name:{ar:'كريدبل إكس',en:'CredibleX'},mark:'CX',country:'ae',products:['working','invoice','purchase','explore'],url:'https://crediblex.io/',reviewed:'2026-11-17',partner:false,kind:'lender',description:{ar:'حلول تمويل مدمج ومستحقات ومدفوعات. الحدود التفصيلية تحتاج تأكيدًا من الجهة.',en:'Embedded, receivables and payables financing; detailed criteria require provider confirmation.'}},
    {id:'fundingsouq-ae',name:{ar:'فندينغ سوق — الإمارات',en:'Funding Souq — UAE'},mark:'FS',country:'ae',products:['working','purchase','explore'],minMonths:24,minRevenue:2000000,url:'https://fundingsouq.com/ae/en/borrow/',reviewed:'2026-11-17',partner:false,kind:'platform',description:{ar:'منصة تمويل أعمال جماعي. يُراجع المنتج والمبلغ مع الجهة.',en:'Business crowdfunding platform; confirm product and amount with the provider.'}},
    {id:'numou',name:{ar:'نمو — سوق تمويل',en:'Numou — Finance marketplace'},mark:'N',country:'ae',products:['working','invoice','purchase','guarantee','explore'],url:'https://www.numou.ae/en',reviewed:'2026-11-17',partner:false,kind:'marketplace',description:{ar:'بوابة وصول إلى عدة جهات تمويل؛ ليست عرض تمويل صادرًا من ميسر.',en:'A gateway to multiple providers, not a financing offer issued by Maysar.'}},
    {id:'lendo',name:{ar:'ليندو',en:'Lendo'},mark:'L',country:'sa',products:['working','invoice','purchase','explore'],url:'https://www.lendo.sa/',reviewed:'2026-11-17',partner:false,kind:'platform',description:{ar:'تمويل الفواتير ورأس المال العامل والتمويل لأجل للمنشآت السعودية.',en:'Invoice, working-capital and term financing for Saudi businesses.'}},
    {id:'tameed',name:{ar:'تعميد',en:'Tameed'},mark:'T',country:'sa',products:['invoice','purchase','explore'],url:'https://www.ta3meed.com/',reviewed:'2026-11-17',partner:false,kind:'platform',description:{ar:'تمويل التعميدات والفواتير والمستخلصات للموردين.',en:'Purchase order, invoice and progress-claim financing for suppliers.'}},
    {id:'manafa',name:{ar:'منافع',en:'Manafa'},mark:'M',country:'sa',products:['working','invoice','purchase','equipment','payroll','guarantee','property','explore'],url:'https://manafa.sa/',reviewed:'2026-11-17',partner:false,kind:'platform',description:{ar:'حلول تمويل منشآت وسلاسل إمداد. تختلف شروط المنتجات.',en:'Business and supply-chain financing; eligibility varies by product.'}}
  ];
  const statuses = ['review','needs_info','ready','submitted','offer','contract','funded','declined','withdrawn'];
  const allowedTransitions = {
    review:['needs_info','ready','declined','withdrawn'], needs_info:['review','ready','declined','withdrawn'],
    ready:['submitted','needs_info','withdrawn'], submitted:['needs_info','offer','declined','withdrawn'],
    offer:['contract','needs_info','declined','withdrawn'], contract:['funded','needs_info','withdrawn'],
    funded:[],declined:[],withdrawn:[]
  };
  const requiredDocs={working:['license','bank'],invoice:['license','bank','invoice'],purchase:['license','bank','contract'],equipment:['license','bank','quotation'],payroll:['license','bank','payroll'],guarantee:['license','bank','contract'],property:['license','bank','project'],explore:['license','bank']};
  function escapeHtml(value=''){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function finite(value){return (typeof value==='number'||typeof value==='string'&&value.trim()!=='')&&Number.isFinite(Number(value));}
  function validateAssessment(a){
    const errors=[];
    if(!['ae','sa','kw','qa','bh','om'].includes(a.country))errors.push('country');
    if(!products.some(p=>p.id===a.product))errors.push('product');
    if(!['trade','tech','industry','health','hospitality','logistics','property','other'].includes(a.sector))errors.push('sector');
    if(!finite(a.months)||Number(a.months)<0||Number(a.months)>1200)errors.push('months');
    if(!finite(a.revenue)||Number(a.revenue)<0||Number(a.revenue)>1e12)errors.push('revenue');
    if(!finite(a.obligations)||Number(a.obligations)<0||Number(a.obligations)>1e10)errors.push('obligations');
    if(!finite(a.amount)||Number(a.amount)<=0||Number(a.amount)>1e9)errors.push('amount');
    if(!String(a.purpose||'').trim()||String(a.purpose).length>1500)errors.push('purpose');
    return errors;
  }
  function matchLender(a,lender){
    const checks=[];
    const push=(key,result,value)=>checks.push({key,result,value});
    push('country',a.country===lender.country,lender.country);
    push('product',lender.products.includes(a.product),a.product);
    push('months',lender.minMonths==null?null:Number(a.months)>=lender.minMonths,lender.minMonths);
    push('revenue',lender.minRevenue==null?null:Number(a.revenue)>=lender.minRevenue,lender.minRevenue);
    push('amount',lender.minAmount==null&&lender.maxAmount==null?null:(!lender.minAmount||Number(a.amount)>=lender.minAmount)&&(!lender.maxAmount||Number(a.amount)<=lender.maxAmount),[lender.minAmount,lender.maxAmount]);
    const status=checks.some(c=>c.result===false)?'excluded':checks.some(c=>c.result===null)?'review':'potential';
    return {lender,checks,status,known:checks.filter(c=>c.result===true).length};
  }
  function matches(a,providers=lenders){
    if(validateAssessment(a).length)return [];
    return providers.map(l=>matchLender(a,l)).filter(m=>m.status!=='excluded').sort((a,b)=>b.known-a.known||a.lender.id.localeCompare(b.lender.id));
  }
  function completeness(company,docs,product='working'){
    const requirements=requiredDocs[product]||requiredDocs.working;
    const fields=['name','license','contact_name','email','phone'];
    const filled=fields.filter(k=>String(company[k]||'').trim()).length;
    const uploaded=requirements.filter(type=>docs.some(d=>d.type===type&&d.status!=='rejected')).length;
    return {percent:Math.round((filled+uploaded)/(fields.length+requirements.length)*100),filled,uploaded,requirements,missing:requirements.filter(type=>!docs.some(d=>d.type===type&&d.status!=='rejected'))};
  }
  function validateFile(file){
    if(!file||!['application/pdf','image/jpeg','image/png'].includes(file.type))return 'type';
    if(file.size<=0||file.size>10*1024*1024)return 'size';
    if(!/\.(pdf|jpe?g|png)$/i.test(file.name))return 'type';
    return null;
  }
  async function verifyFileSignature(file){
    const b=new Uint8Array(await file.slice(0,8).arrayBuffer());
    if(file.type==='application/pdf')return new TextDecoder().decode(b.slice(0,5))==='%PDF-';
    if(file.type==='image/png')return b[0]===137&&b[1]===80&&b[2]===78&&b[3]===71&&b[4]===13&&b[5]===10&&b[6]===26&&b[7]===10;
    if(file.type==='image/jpeg')return b[0]===255&&b[1]===216&&b[2]===255;
    return false;
  }
  function nextStatus(current,next,note='',reference=''){
    if(!allowedTransitions[current]?.includes(next))throw new Error('invalid_transition');
    if(!note.trim())throw new Error('note_required');
    if(['submitted','funded'].includes(next)&&!reference.trim())throw new Error('reference_required');
    return next;
  }
  function compareOffers(offers){
    return offers.map(o=>{
      const amount=Number(o.amount),months=Number(o.months),payment=Number(o.monthly_payment),fees=Number(o.fees||0);
      if(!Number.isFinite(amount)||amount<=0||!Number.isInteger(months)||months<1||months>360||!Number.isFinite(payment)||payment<=0||!Number.isFinite(fees)||fees<0||fees>=amount)throw new Error('invalid_offer');
      return {...o,amount,months,monthly_payment:payment,fees,net:amount-fees,total:months*payment+fees};
    });
  }
  const currency=country=>({ae:'AED',sa:'SAR',kw:'KWD',qa:'QAR',bh:'BHD',om:'OMR'})[country]||'AED';
  const uid=()=>crypto.randomUUID();
  const reference=id=>'MY-'+id.replace(/-/g,'').slice(0,8).toUpperCase();
  window.MaysarDomain={products,lenders,statuses,allowedTransitions,requiredDocs,escapeHtml,validateAssessment,matchLender,matches,completeness,validateFile,verifyFileSignature,nextStatus,compareOffers,currency,uid,reference};
})();
