"use strict";
window.MAYSAR_CONFIG = Object.freeze({
  supabaseUrl: "",
  supabasePublishableKey: "",
  paymentsEnabled: false,
  supportEmail: "",
  version: "2.1.0"
});
