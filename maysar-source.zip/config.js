"use strict";
window.MAYSAR_CONFIG = Object.freeze({
  supabaseUrl: "",
  supabasePublishableKey: "",
  paymentsEnabled: false,
  supportEmail: "",
  version: "2.0.0"
});
