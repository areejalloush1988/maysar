import fs from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const dist=path.join(root,'dist');
await fs.rm(dist,{recursive:true,force:true});await fs.mkdir(dist,{recursive:true});
const files=['theme.css','config.js','core.js','storage.js','pdf-v2.js','views.js','ui.js','manifest.webmanifest'];
await fs.copyFile(path.join(root,'app-v2.html'),path.join(dist,'index.html'));
for(const file of files)await fs.copyFile(path.join(root,file),path.join(dist,file));
await fs.cp(path.join(root,'assets'),path.join(dist,'assets'),{recursive:true});
await fs.writeFile(path.join(dist,'.nojekyll'),'');
let html=await fs.readFile(path.join(root,'app-v2.html'),'utf8');
let css=await fs.readFile(path.join(root,'theme.css'),'utf8');
const assetPaths=[...new Set([...css.matchAll(/url\(['"]?(assets\/[^)'" ]+)['"]?\)/g)].map(x=>x[1]))];
for(const file of assetPaths){const bytes=await fs.readFile(path.join(root,file));const mime=file.endsWith('.woff')?'font/woff':file.endsWith('.png')?'image/png':'image/webp';css=css.split(file).join(`data:${mime};base64,${bytes.toString('base64')}`);}
html=html.replace(/<link rel="stylesheet" href="theme.css">/,()=>`<style>${css}</style>`).replace(/\s*<link rel="preload"[^>]+>/g,'').replace(/\s*<link rel="manifest"[^>]+>/g,'');
let scripts='';
for(const file of ['config.js','core.js','storage.js','pdf-v2.js','views.js','ui.js']){let code=await fs.readFile(path.join(root,file),'utf8');code=code.replace(/<\/script/gi,'<\\/script');html=html.replace(`<script src="${file}" defer></script>`,'');scripts+=`<script>${code}</script>\n`;}
html=html.replace('</body>',()=>scripts+'</body>');
const embeddedPaths=[...new Set([...html.matchAll(/assets\/[a-zA-Z0-9_./-]+\.(?:png|webp|svg|woff)/g)].map(m=>m[0]))];
for(const file of embeddedPaths){const asset=await fs.readFile(path.join(root,file));const mime=file.endsWith('.svg')?'image/svg+xml':file.endsWith('.woff')?'font/woff':file.endsWith('.webp')?'image/webp':'image/png';html=html.split(file).join(`data:${mime};base64,${asset.toString('base64')}`);}
const out=process.env.MAYSAR_OUTPUT_DIR||path.join(root,'artifacts');
await fs.mkdir(out,{recursive:true});
await fs.writeFile(path.join(out,'Maysar-App.html'),html);
console.log(JSON.stringify({dist,standalone:path.join(out,'Maysar-App.html'),files:files.length+2}));
